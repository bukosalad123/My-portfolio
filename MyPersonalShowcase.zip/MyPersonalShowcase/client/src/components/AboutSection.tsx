import { Card } from "@/components/ui/card";
import { Code, Palette, Rocket } from "lucide-react";
import profilePhoto from "@assets/Screenshot 2025-10-06 22.27.24_1759760882036.png";

export default function AboutSection() {
  const highlights = [
    {
      icon: Code,
      title: "Development",
      description: "Building scalable web applications with modern technologies",
    },
    {
      icon: Palette,
      title: "Design",
      description: "Creating intuitive and beautiful user experiences",
    },
    {
      icon: Rocket,
      title: "Innovation",
      description: "Always learning and pushing the boundaries of what's possible",
    },
  ];

  return (
    <section className="py-20 md:py-32 px-6" data-testid="section-about">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col items-center mb-16">
          <div 
            className="relative mb-6 group"
            style={{
              animation: "fade-in-up 0.6s ease-out",
            }}
          >
            <div className="w-40 h-40 rounded-full overflow-hidden border-4 border-primary/20 group-hover:border-primary/40 transition-all">
              <img 
                src={profilePhoto} 
                alt="Veronque Andrie"
                className="w-full h-full object-cover transition-transform group-hover:scale-110"
                data-testid="img-profile"
              />
            </div>
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <div 
            className="text-center space-y-2"
            style={{
              animation: "fade-in-up 0.6s ease-out",
              animationDelay: "0.2s",
              animationFillMode: "both",
            }}
          >
            <h3 className="text-2xl font-bold" data-testid="text-profile-name">
              Veronque Andrie
            </h3>
            <p className="text-muted-foreground" data-testid="text-profile-title">
              4th Year IT Student
            </p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-start">
          <div className="space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold" data-testid="text-about-title">
              About Me
            </h2>
            <div className="space-y-4 text-lg text-muted-foreground">
              <p data-testid="text-about-paragraph-1">
                I'm a passionate designer and developer with a keen eye for detail and a love for creating
                exceptional digital experiences. With years of experience in the field, I've had the
                privilege of working on diverse projects that challenge and inspire me.
              </p>
              <p data-testid="text-about-paragraph-2">
                My approach combines technical expertise with creative thinking, allowing me to deliver
                solutions that are not only functional but also beautiful and user-friendly. I believe in
                the power of good design to make a positive impact on people's lives.
              </p>
            </div>
          </div>

          <div className="grid gap-6">
            {highlights.map((item, index) => (
              <Card
                key={item.title}
                className="p-6 hover-elevate transition-all cursor-pointer"
                style={{
                  animation: "fade-in-up 0.6s ease-out",
                  animationDelay: `${index * 0.1}s`,
                  animationFillMode: "both",
                }}
                data-testid={`card-highlight-${index}`}
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-primary/10 text-primary">
                    <item.icon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold mb-2" data-testid={`text-highlight-title-${index}`}>
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground" data-testid={`text-highlight-desc-${index}`}>
                      {item.description}
                    </p>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
