import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Award, X, ZoomIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface CertificationCardProps {
  title: string;
  organization: string;
  date: string;
  description: string;
  image?: string;
  verifyLink?: string;
}

export default function CertificationCard({
  title,
  organization,
  date,
  description,
  image,
  verifyLink,
}: CertificationCardProps) {
  const [isImageOpen, setIsImageOpen] = useState(false);

  const handleVerify = () => {
    if (verifyLink) {
      window.open(verifyLink, '_blank');
    }
  };

  const handleViewCertificate = () => {
    setIsImageOpen(true);
  };

  return (
    <>
      <Card className="hover-elevate transition-all h-full group" data-testid="card-certification">
        {image && (
          <div 
            className="relative aspect-video overflow-hidden cursor-pointer bg-card"
            onClick={handleViewCertificate}
          >
            <img 
              src={image} 
              alt={title}
              className="w-full h-full object-contain transition-transform group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <div className="bg-primary/90 backdrop-blur-sm p-3 rounded-full">
                <ZoomIn className="w-6 h-6 text-primary-foreground" />
              </div>
            </div>
          </div>
        )}
        <CardContent className="p-6 space-y-4">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-lg bg-primary/10 text-primary">
              <Award className="w-6 h-6" />
            </div>
            <div className="flex-1 space-y-2">
              <h3 className="text-xl font-semibold" data-testid="text-cert-title">
                {title}
              </h3>
              <p className="text-muted-foreground font-medium" data-testid="text-cert-org">
                {organization}
              </p>
              <Badge variant="secondary" data-testid="badge-cert-date">
                {date}
              </Badge>
            </div>
          </div>
          <p className="text-muted-foreground text-sm" data-testid="text-cert-description">
            {description}
          </p>
          <div className="flex gap-2">
            {image && (
              <Button
                variant="default"
                size="sm"
                onClick={handleViewCertificate}
                className="flex-1 gap-2"
                data-testid="button-view-cert"
              >
                <ZoomIn className="w-4 h-4" />
                View Certificate
              </Button>
            )}
            {verifyLink && (
              <Button
                variant="outline"
                size="sm"
                onClick={handleVerify}
                className="flex-1 gap-2"
                data-testid="button-verify"
              >
                <ExternalLink className="w-4 h-4" />
                Verify
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={isImageOpen} onOpenChange={setIsImageOpen}>
        <DialogContent className="max-w-5xl p-0 overflow-hidden">
          <div className="relative">
            <button
              onClick={() => setIsImageOpen(false)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-background/80 backdrop-blur-sm hover-elevate transition-all"
              data-testid="button-close-dialog"
            >
              <X className="w-5 h-5" />
            </button>
            <img 
              src={image} 
              alt={title}
              className="w-full h-auto"
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
