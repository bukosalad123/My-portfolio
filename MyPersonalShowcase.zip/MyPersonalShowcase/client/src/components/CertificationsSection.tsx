import CertificationCard from "./CertificationCard";
import cppCert from "@assets/553641526_1336881531180408_4644968332236568563_n_1759712073979.jpg";
import pythonCert from "@assets/554284743_1870031643931582_6935027939072047250_n_1759712087897.jpg";
import aiWorkCert from "@assets/553444132_2868110373578955_6256766053906682403_n_1759712100728.jpg";
import azureCert from "@assets/554239109_1433640951050715_8347678147710202736_n (1)_1759712112724.jpg";
import googleCloudCert from "@assets/553742495_739798445757969_3096240868742036437_n_1759712128106.jpg";

export default function CertificationsSection() {
  const certifications = [
    {
      title: "C++ Essentials 1",
      organization: "Cisco Networking Academy",
      date: "September 18, 2025",
      description: "Successfully completed C++ Essentials 1 certification offered by Networking Academy through the Cisco Networking Academy program.",
      image: cppCert,
      verifyLink: "https://www.netacad.com/",
    },
    {
      title: "Python Essentials 1",
      organization: "Cisco Networking Academy",
      date: "September 8, 2025",
      description: "Successfully completed Python Essentials 1 certification offered by Networking Academy through the Cisco Networking Academy program.",
      image: pythonCert,
      verifyLink: "https://www.netacad.com/",
    },
    {
      title: "AI at Work: Analyze Customer Reviews",
      organization: "DICT-ITU DTC Initiative",
      date: "September 9, 2025",
      description: "Successfully completed AI at Work: Analyze Customer Reviews certification offered by DICT-ITU DTC Initiative through the Cisco Networking Academy program.",
      image: aiWorkCert,
      verifyLink: "https://www.netacad.com/",
    },
    {
      title: "Plan and prepare to develop AI solutions on Azure",
      organization: "Microsoft",
      date: "September 16, 2025",
      description: "Successfully completed Microsoft certification on planning and preparing to develop AI solutions on Azure platform.",
      image: azureCert,
      verifyLink: "https://learn.microsoft.com/",
    },
    {
      title: "Google Cloud Computing Foundations: Cloud Computing Fundamentals",
      organization: "Google Cloud",
      date: "2025",
      description: "Completion badge for Google Cloud Computing Foundations: Cloud Computing Fundamentals certification.",
      image: googleCloudCert,
      verifyLink: "https://cloud.google.com/learn/certification",
    },
  ];

  return (
    <section className="py-20 md:py-32 px-6 bg-card/30" data-testid="section-certifications">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-certifications-title">
            Certifications & Achievements
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-certifications-subtitle">
            Professional certifications that validate my expertise and commitment to continuous learning
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certifications.map((cert, index) => (
            <div
              key={index}
              style={{
                animation: "fade-in-up 0.6s ease-out",
                animationDelay: `${index * 0.1}s`,
                animationFillMode: "both",
              }}
            >
              <CertificationCard {...cert} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
