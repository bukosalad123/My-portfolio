import { Heart } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-8 px-6 border-t border-border" data-testid="footer">
      <div className="max-w-7xl mx-auto">
        <div className="text-center text-muted-foreground">
          <p className="flex items-center justify-center gap-2" data-testid="text-footer-copyright">
            © {currentYear} Portfolio. Made with{" "}
            <Heart className="w-4 h-4 text-primary fill-primary" /> by a Creative Professional
          </p>
        </div>
      </div>
    </footer>
  );
}
