import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const scrollToNext = () => {
    const aboutSection = document.getElementById("about");
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleContactClick = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <section
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
      data-testid="section-hero"
    >
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background:
            "radial-gradient(circle at 30% 50%, hsl(270 70% 65% / 0.3) 0%, transparent 50%), radial-gradient(circle at 70% 50%, hsl(180 65% 55% / 0.2) 0%, transparent 50%)",
          backgroundSize: "200% 200%",
          animation: "gradient-shift 8s ease infinite",
        }}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <div className="space-y-6 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
          <h1
            className="text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight"
            data-testid="text-hero-title"
          >
            <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Veronque Andrie
            </span>
          </h1>

          <p
            className="text-xl md:text-2xl text-muted-foreground mb-8 animate-fade-in-up"
            style={{ animationDelay: "0.2s" }}
            data-testid="text-hero-tagline"
          >
            Aspiring Engineer
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <Button
              size="lg"
              onClick={handleContactClick}
              className="animate-fade-in-up"
              style={{ animationDelay: "0.4s" }}
              data-testid="button-contact-cta"
            >
              Get In Touch
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => console.log("Viewing work")}
              className="animate-fade-in-up backdrop-blur-sm"
              style={{ animationDelay: "0.5s" }}
              data-testid="button-view-work"
            >
              View My Work
            </Button>
          </div>
        </div>
      </div>

      <button
        onClick={scrollToNext}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground hover:text-foreground transition-colors animate-bounce-subtle"
        data-testid="button-scroll-indicator"
      >
        <ChevronDown className="w-8 h-8" />
      </button>
    </section>
  );
}