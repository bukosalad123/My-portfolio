import ProjectCard from "./ProjectCard";
import buddyDashImg from "@assets/Screenshot 2025-10-08 22.47.24_1759935645560.png";
import libraryImg from "@assets/Screenshot 2025-10-08 22.41.57_1759935672769.png";
import aiImg from "@assets/Screenshot 2025-10-08 22.45.37_1759935694999.png";
import webTrackerImg from "@assets/Screenshot 2025-10-08 22.46.46_1759935718726.png";

export default function PortfolioSection() {
  const projects = [
    {
      title: "Web Tracker System",
      description: "Advanced web analytics platform with real-time visitor tracking, heatmaps, session recording, and comprehensive dashboard for monitoring user behavior and site performance.",
      tags: ["Python", "PostgreSQL", "React", "Analytics"],
      link: "https://gitlab.com/veronqueandrie415-group/web-tracker-system",
      hostedBy: "GitLab",
      image: webTrackerImg,
    },
    {
      title: "AI Facial Recognition",
      description: "Intelligent facial recognition system powered by machine learning for secure authentication, attendance tracking, and identity verification with high accuracy rate.",
      tags: ["Python", "OpenCV", "TensorFlow", "AI/ML"],
      link: "https://gitlab.com/veronqueandrie415-group/ai-facial-recognition",
      hostedBy: "GitLab",
      image: aiImg,
    },
    {
      title: "BuddyDash",
      description: "A comprehensive dashboard application for managing tasks, collaborations, and team workflows with real-time updates and analytics.",
      tags: ["React", "TypeScript", "Tailwind CSS"],
      link: "https://gitlab.com/veronqueandrie415-group/BuddyDash",
      hostedBy: "GitLab",
      image: buddyDashImg,
    },
    {
      title: "Library Management System",
      description: "Full-featured library management system with book cataloging, member management, borrowing tracking, and automated notifications.",
      tags: ["React", "Node.js", "Express", "MongoDB"],
      link: "https://gitlab.com/veronqueandrie415-group/LibrayManagement-System",
      hostedBy: "GitLab",
      image: libraryImg,
    },
  ];

  return (
    <section className="py-20 md:py-32 px-6 bg-card/30" data-testid="section-portfolio">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-portfolio-title">
            Featured Projects
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto" data-testid="text-portfolio-subtitle">
            A selection of projects that showcase my skills and passion for creating exceptional digital experiences
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              style={{
                animation: "fade-in-up 0.6s ease-out",
                animationDelay: `${index * 0.1}s`,
                animationFillMode: "both",
              }}
            >
              <ProjectCard {...project} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}