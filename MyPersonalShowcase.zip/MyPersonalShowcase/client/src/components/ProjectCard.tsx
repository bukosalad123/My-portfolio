import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink } from "lucide-react";

interface ProjectCardProps {
  title: string;
  description: string;
  image?: string;
  tags: string[];
  link?: string;
  hostedBy?: string;
}

export default function ProjectCard({ title, description, image, tags, link, hostedBy }: ProjectCardProps) {
  const handleClick = () => {
    if (link) {
      window.open(link, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <Card
      className="group overflow-hidden hover-elevate transition-all cursor-pointer h-full"
      onClick={handleClick}
      data-testid="card-project"
    >
      <div className="relative aspect-video bg-gradient-to-br from-primary/20 to-accent/20 overflow-hidden">
        {image ? (
          <img 
            src={image} 
            alt={title}
            className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-300"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-6xl font-bold text-muted-foreground/10">
              {title.charAt(0)}
            </div>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end justify-center pb-6">
          <div className="flex items-center gap-2 text-sm text-foreground bg-card/80 backdrop-blur-sm px-4 py-2 rounded-lg border border-border">
            <ExternalLink className="w-4 h-4" />
            <span>View Project</span>
          </div>
        </div>
      </div>
      <CardContent className="p-6 space-y-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-2xl font-semibold" data-testid="text-project-title">
            {title}
          </h3>
          {hostedBy && (
            <Badge variant="outline" className="text-xs whitespace-nowrap">
              🦊 {hostedBy}
            </Badge>
          )}
        </div>
        <p className="text-muted-foreground" data-testid="text-project-description">
          {description}
        </p>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, index) => (
            <Badge key={index} variant="secondary" data-testid={`badge-tag-${index}`}>
              {tag}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
