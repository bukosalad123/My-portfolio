import { Card } from "@/components/ui/card";

interface SkillCardProps {
  logo: string;
  name: string;
}

export default function SkillCard({ logo, name }: SkillCardProps) {
  return (
    <Card className="p-6 hover-elevate transition-all cursor-pointer group" data-testid="card-skill">
      <div className="flex flex-col items-center text-center space-y-4">
        <div className="p-4 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
          <img 
            src={logo} 
            alt={`${name} logo`} 
            className="w-12 h-12 object-contain"
            onError={(e) => {
              e.currentTarget.src = 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/devicon/devicon-original.svg';
            }}
          />
        </div>
        <h3 className="font-semibold text-lg" data-testid="text-skill-name">
          {name}
        </h3>
      </div>
    </Card>
  );
}
