import AboutSection from "../AboutSection";

export default function AboutSectionExample() {
  return (
    <div className="bg-background">
      <AboutSection />
    </div>
  );
}
