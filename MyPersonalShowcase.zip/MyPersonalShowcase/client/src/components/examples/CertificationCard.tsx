import CertificationCard from "../CertificationCard";
import cppCert from "@assets/553641526_1336881531180408_4644968332236568563_n_1759712073979.jpg";

export default function CertificationCardExample() {
  return (
    <div className="p-6 max-w-md">
      <CertificationCard
        title="C++ Essentials 1"
        organization="Cisco Networking Academy"
        date="Sep 18, 2025"
        description="Successfully completed C++ Essentials 1 certification"
        image={cppCert}
        verifyLink="https://www.netacad.com/"
      />
    </div>
  );
}
