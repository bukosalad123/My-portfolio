import PortfolioSection from "../PortfolioSection";

export default function PortfolioSectionExample() {
  return <PortfolioSection />;
}
