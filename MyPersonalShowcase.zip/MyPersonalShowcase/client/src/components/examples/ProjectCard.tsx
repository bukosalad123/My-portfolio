import ProjectCard from "../ProjectCard";

export default function ProjectCardExample() {
  return (
    <div className="p-6 max-w-md">
      <ProjectCard
        title="E-Commerce Platform"
        description="A modern e-commerce solution with advanced features"
        tags={["React", "Node.js", "MongoDB"]}
        link="https://example.com"
      />
    </div>
  );
}
