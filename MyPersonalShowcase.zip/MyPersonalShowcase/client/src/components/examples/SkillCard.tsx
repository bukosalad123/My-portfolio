import SkillCard from "../SkillCard";
import { Code } from "lucide-react";

export default function SkillCardExample() {
  return (
    <div className="p-6 max-w-xs">
      <SkillCard icon={Code} name="React" level={90} />
    </div>
  );
}
