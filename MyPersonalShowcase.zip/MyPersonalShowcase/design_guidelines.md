# Personal Portfolio Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from modern portfolio leaders like Stripe's clean aesthetic, Linear's typography excellence, and Behance's project showcases, while incorporating the dark purple theme from the provided screenshot.

## Core Design Principles
1. **Professional Elegance**: Sophisticated dark theme that showcases work without distraction
2. **Purposeful Motion**: Strategic animations that guide attention and enhance narrative
3. **Visual Hierarchy**: Clear content structure that leads visitors through your story
4. **Interactive Engagement**: Thoughtful hover states and transitions that invite exploration

## Color Palette

### Dark Mode (Primary)
- **Background Primary**: 260 35% 8% (deep purple-black)
- **Background Secondary**: 260 30% 12% (slightly lighter purple)
- **Background Elevated**: 260 25% 15% (card/section backgrounds)
- **Primary Brand**: 270 70% 65% (vibrant purple - for CTAs and highlights)
- **Accent**: 180 65% 55% (cyan - for interactive elements and links)
- **Text Primary**: 0 0% 95% (near-white)
- **Text Secondary**: 260 10% 70% (muted purple-gray)
- **Border/Divider**: 260 20% 20% (subtle purple borders)

### Light Mode (Secondary Option)
- **Background**: 0 0% 98%
- **Text**: 260 35% 15%
- **Primary**: 270 65% 55%
- **Accent**: 180 60% 45%

## Typography

### Font Families
- **Primary (Headings)**: 'Inter', sans-serif - weights: 700, 800
- **Secondary (Body)**: 'Inter', sans-serif - weights: 400, 500, 600
- **Accent (Code/Technical)**: 'JetBrains Mono', monospace - weight: 400

### Type Scale
- **Hero Heading**: text-6xl md:text-7xl lg:text-8xl, font-bold, tracking-tight
- **Section Heading**: text-4xl md:text-5xl, font-bold
- **Card Title**: text-2xl md:text-3xl, font-semibold
- **Body Large**: text-lg, font-normal
- **Body Regular**: text-base, font-normal
- **Caption**: text-sm, text-secondary

## Layout System

### Spacing Primitives
Use Tailwind units: **4, 6, 8, 12, 16, 20, 24** for consistent rhythm
- Section padding: py-20 md:py-32
- Container max-width: max-w-7xl
- Content max-width: max-w-4xl
- Grid gaps: gap-6 md:gap-8

### Grid System
- Projects grid: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Skills grid: grid-cols-2 md:grid-cols-3 lg:grid-cols-4
- Certifications: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

## Component Library

### Navigation
- Fixed top navigation with blur backdrop (backdrop-blur-xl bg-background/80)
- Logo/name on left, nav links center, CTA button right
- Mobile: Hamburger menu with smooth slide-in drawer
- Active state: border-b-2 with primary color

### Hero Section (Home)
- Full viewport height (min-h-screen) with centered content
- Large heading with fade-in animation on load
- Professional tagline below name
- Animated gradient background with subtle particle effect
- Scroll indicator at bottom
- NO large hero image - focus on typography and motion

### Project Cards (Portfolio)
- Elevated background with rounded corners (rounded-2xl)
- Project thumbnail with hover zoom (scale-105 transition)
- Overlay gradient on hover revealing project details
- Title, brief description, tech stack tags
- "View Project" CTA appears on hover
- Case study link for detailed projects

### Skill Bars/Cards
- Icon + skill name + proficiency indicator
- Animated progress bars that fill on scroll-into-view
- Grouped by category (Frontend, Backend, Design, Tools)
- Hover effect: slight lift with shadow enhancement

### Certification Cards
- Certificate image thumbnail
- Organization logo
- Title and date
- "Verify" link with external icon
- Grid layout with consistent card heights

### Contact Form
- Clean form fields with subtle border glow on focus
- Floating labels or placeholder text
- Submit button with loading state animation
- Success/error message micro-interaction

### Buttons
- Primary: Solid background with primary color, rounded-lg, px-6 py-3
- Secondary: Outline variant with border-2
- Hover: Slight scale-105, enhanced shadow
- Backdrop blur for buttons over images

## Animation Strategy

### Page Load
- Hero content: Staggered fade-in (name → tagline → CTA) over 1.2s
- Navigation: Slide down from top (300ms delay)

### Scroll Animations
- Fade-in + slide-up for section headings and cards as they enter viewport
- Parallax: Background elements move 0.5x scroll speed
- Skill bars: Animate width from 0 to target on scroll-in

### Hover Effects
- Project cards: Image zoom + overlay reveal
- Buttons: Scale-105 + enhanced shadow
- Skill cards: Subtle lift (translateY(-4px))
- Links: Underline animation from left

### Micro-interactions
- Form submit: Button morphs to checkmark
- Scroll indicator: Gentle bounce animation
- Nav links: Smooth color transition on hover

## Section Structure

1. **Hero/Home**: Full screen introduction with animated background
2. **About Me**: Two-column layout (photo left, bio right), personal story
3. **Portfolio**: 3-column project grid with filters, featured work highlighted
4. **Skills & Expertise**: Icon grid with categories and proficiency levels
5. **Certifications**: Showcase grid with project highlights
6. **Resume/Experience**: Timeline layout with downloadable PDF
7. **Contact**: Form + social links + availability status

## Images

### Profile Photo
- Location: About Me section, left column
- Style: Rounded or slightly rounded corners, professional headshot
- Size: 400x400px minimum
- Description: Professional portrait with good lighting against neutral or blurred background

### Project Thumbnails
- Location: Portfolio section grid
- Style: Consistent aspect ratio (16:9 or 4:3)
- Size: 800x600px minimum
- Description: High-quality screenshots or mockups of completed projects, showing key interface elements

### Certification Badges
- Location: Certifications section
- Style: Official certificate images or badge graphics
- Size: Varies by certificate
- Description: Actual certification badges/logos from issuing organizations

**Note**: No large hero image - the hero section relies on typography, gradient background, and subtle particle animations for visual impact.

## Performance Considerations
- Use CSS transforms for animations (GPU-accelerated)
- Intersection Observer for scroll-triggered animations
- Lazy load project images below the fold
- Preload critical fonts
- Debounce scroll events

## Accessibility
- Maintain WCAG AA contrast ratios on dark background
- Provide "reduce motion" alternative for users with motion sensitivity
- Keyboard navigation for all interactive elements
- Semantic HTML structure with proper heading hierarchy
- Focus indicators with primary color ring